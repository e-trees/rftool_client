
class StgTimeoutError(Exception):
    pass

class DigitalOutTimeoutError(Exception):
    pass
